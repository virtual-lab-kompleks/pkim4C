const reagents = document.querySelectorAll('.reagent');
const beaker = document.getElementById('beaker');
const canvas = document.getElementById('liquidCanvas');
const ctx = canvas.getContext('2d');
const reactionInfo = document.getElementById('reaction-info');

let contents = [];

function drawLiquid(color) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, canvas.height);
  ctx.lineTo(0, canvas.height - 100);
  ctx.lineTo(canvas.width, canvas.height - 100);
  ctx.lineTo(canvas.width, canvas.height);
  ctx.closePath();
  ctx.fill();
}

function getReactionResult(contents) {
  const combinations = {
    'Cu2+_NH3': { color: 'blue', complex: '[Cu(NH₃)₄]²⁺' },
    'Ni2+_H2O': { color: 'green', complex: '[Ni(H₂O)₆]²⁺' },
    'Fe3+_CN-': { color: 'yellow', complex: '[Fe(CN)₆]³⁻' },
  };

  for (let combo in combinations) {
    const [ion, ligan] = combo.split('_');
    if (contents.includes(ion) && contents.includes(ligan)) {
      return combinations[combo];
    }
  }
  return null;
}

reagents.forEach(reagent => {
  reagent.addEventListener('dragstart', e => {
    e.dataTransfer.setData('text/plain', e.target.dataset.type);
  });
});

beaker.addEventListener('dragover', e => {
  e.preventDefault();
});

beaker.addEventListener('drop', e => {
  e.preventDefault();
  const data = e.dataTransfer.getData('text/plain');
  contents.push(data);
  const result = getReactionResult(contents);
  if (result) {
    drawLiquid(result.color);
    reactionInfo.innerHTML = `<p>Kompleks terbentuk: ${result.complex}</p>`;
  }
});
